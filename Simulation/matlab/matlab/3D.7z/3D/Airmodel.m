global A
